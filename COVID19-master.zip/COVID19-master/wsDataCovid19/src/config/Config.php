<?php
define('API_KEY','e14c60816f8af99193f62a811e6afbbf');
?>
